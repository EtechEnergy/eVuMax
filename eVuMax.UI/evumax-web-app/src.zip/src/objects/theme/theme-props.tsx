
export default class ThemeProps {
    PropValue: string | number | string[] | undefined = "";
    PropName: string | number | string[] | undefined = "";//Common
}

