﻿export class SQLCredential {
  User: string = "";
  Password: string = "";
  ServerName: string = "";
  UseWindowsAuthentication: boolean = false;
}
