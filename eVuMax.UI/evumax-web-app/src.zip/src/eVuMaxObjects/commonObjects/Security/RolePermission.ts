﻿export class RolePermission {
  PermissionID: number = 0;
  PermissionName: string = "";
}
