﻿export class SettingValue {
  SettingID: string = "";
  SettingName: string = "";
  Value: string = "";
  SettingType: string = "GLOBAL";
  NeedToSave: boolean = false;
}
