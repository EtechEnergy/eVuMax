﻿

    export class mudLogLithology  {

        lithID: string = "";
        lithType: string = "";
        Percentage: number = 0;
        Image: any;
        Description: string = "";
        DisplayOrder: number = 0;

        constructor() {
                    this.lithID = "";
                    this.lithType = "";
                    this.Percentage = 0;
                    this.Image = "";
                    this.Description = "";
                    this.DisplayOrder = 0;
                }

    }


