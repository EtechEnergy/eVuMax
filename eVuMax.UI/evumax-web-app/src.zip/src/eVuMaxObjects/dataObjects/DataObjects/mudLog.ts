﻿
import {mudLogInterval} from "./mudLogInterval";

    export class mudLog {

        WellID: string = "";
        WellboreID: string = "";
        mudLogID: string = "";
        mudLogName: string = "";
        Description: string = "";
        WMLSURL: string = "";
        LibID: string = "";
        wmlpurl: string = "";
        ServerKey: string = "";
        intervals: mudLogInterval[] = []; //important to define as this only

    }
