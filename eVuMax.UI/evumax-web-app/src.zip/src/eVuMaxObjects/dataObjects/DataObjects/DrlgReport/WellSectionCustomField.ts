﻿export class WellSectionCustomField {
  WellID: string = "";
  EntryID: string = "";
  ParameterID: string = "";
  ParameterValue: number = 0;
}
