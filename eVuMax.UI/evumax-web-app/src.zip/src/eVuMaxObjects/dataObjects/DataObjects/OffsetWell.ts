    export class OffsetWell {
        OffsetWellID: string = "";
        OffsetWellUWI: string = "";
    }
