﻿export class HookloadPlanData {
  Depth: number = 0;
  Weight: number = 0;
  MaxTension: number = 0;
  MinTension: number = 0;
  MaxCompress: number = 0;
  MinCompress: number = 0;
}
