﻿export class activity {
  ObjectID: string = "";
  Duration: number = 0;
  Comments: string = "";
}
