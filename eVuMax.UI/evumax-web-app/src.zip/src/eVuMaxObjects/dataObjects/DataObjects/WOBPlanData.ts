﻿

    export class WOBPlanData {
        MD: number = 0;
        MinWOB: number = 0;
        MaxWOB: number = 0;
    }


