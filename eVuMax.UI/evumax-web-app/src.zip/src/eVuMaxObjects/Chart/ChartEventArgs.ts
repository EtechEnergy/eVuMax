export class ChartEventArgs {
    chartId: string;
}
