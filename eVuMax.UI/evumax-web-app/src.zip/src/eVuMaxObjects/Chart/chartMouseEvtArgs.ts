export class ChartMouseEvtArgs {
	seriesId: string;
	button: number;
    index: number;
    x: number;
    y: number;
}
