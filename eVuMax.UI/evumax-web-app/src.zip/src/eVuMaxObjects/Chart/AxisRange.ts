export class AxisRange {

    Min: number;
    Max: number;

    MaxWidthLabel: string;

    // MinMultiLine: string;
    // MaxMultiLine: string;
}



export class AxisDateRange {
    Min: Date;
    Max: Date;
}

