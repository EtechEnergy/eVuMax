export class ChartRectangle {

    left: number = 0;
    top: number = 0;
    right: number = 0;
    bottom: number = 0;
    width: number = 0;
    height: number = 0;
    LeftEdge: number = 0;
}