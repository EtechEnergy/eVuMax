import { Axis } from "../Chart/Axis";


export class ZoomStep {
    AxisId: string = "";
    Min: number = 0;
    Max: number = 0;
}