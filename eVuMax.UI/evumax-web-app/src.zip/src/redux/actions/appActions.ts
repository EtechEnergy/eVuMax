import * as TypeActions from "../types/typesActions";
export type AppActions = TypeActions.LoginActionsTypes | TypeActions.StatusActionsTypes;