import React from "react";

export default class DahboardSettings extends React.Component {

    componentDidMount(){

        
    }

render(){
    return(
<div>
<a  className="closebtn" ></a>
                    <a href="#">About</a>
                    <a href="#">Services</a>
                    <a href="#">Clients</a>
                    <a href="#">Contact</a>
</div>

    )
}

}