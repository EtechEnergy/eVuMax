﻿import React from "react";


export default class PageNotFound extends React.Component { }