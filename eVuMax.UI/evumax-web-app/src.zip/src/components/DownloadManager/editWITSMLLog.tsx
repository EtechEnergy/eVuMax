import React, { Component } from 'react'



export default class EditWITSMLLog extends Component {




    //Grid Data
//     For Each objChannel As logChannel In newValue.logCurves.Values

//     grdChannels.Rows(rowCounter).Cells("COL_MNEMONIC").Value = objChannel.witsmlMnemonic
//     grdChannels.Rows(rowCounter).Cells("COL_DESCRIPTION").Value = objChannel.curveDescription
//     grdChannels.Rows(rowCounter).Cells("COL_UNIT").Value = objChannel.unit
//     grdChannels.Rows(rowCounter).Cells("COL_START_INDEX").Value = objChannel.startIndex
//     grdChannels.Rows(rowCounter).Cells("COL_END_INDEX").Value = objChannel.endIndex
//     grdChannels.Rows(rowCounter).Cells("COL_MIN_INDEX").Value = objChannel.minIndex
//     grdChannels.Rows(rowCounter).Cells("COL_MAX_INDEX").Value = objChannel.maxIndex

//     rowCounter += 1
// Next
    render() {
        return (
            <div>

            </div>
        )
    }
}


