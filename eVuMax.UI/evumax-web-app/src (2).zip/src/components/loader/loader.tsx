import React from "react";
import './loader.css';


export default class ProcessLoader extends React.Component { 

   

render(){

    return(
        <div>
           <div className="lds-dual-ring"></div>
        </div>
    )
}

}