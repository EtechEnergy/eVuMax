﻿export class ImageLogChannels {
  Mnemonic: string = "";
  DisplayOrder: number = 0;
}
