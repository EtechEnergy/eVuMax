﻿
export class RMEntries {
  roadmapID: string = "";
  depth: number = 0;
  minValue: number = 0;
  maxValue: number = 0;
}
