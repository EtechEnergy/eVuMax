﻿export class dayCost {
  ObjectID: string = "";
  CostCode: string = "";
  CostSubCode: string = "";
  CostDescription: string = "";
  CostPerItem: number = 0;
  ItemSize: number = 0;
  Qty: number = 0;
  Amount: number = 0;
  Vendor: string = "";
}
