﻿    export class SideTrack {
        SideTrackID: string = "";
        DateTime: string = "";
        Type: number = 0;
    }

