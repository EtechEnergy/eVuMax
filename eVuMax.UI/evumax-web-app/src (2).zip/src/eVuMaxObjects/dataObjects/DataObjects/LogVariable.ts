﻿export class LogVariable {
  VarID: string = "";
  VarName: string = "";
  VarValue: number = 0;
}
