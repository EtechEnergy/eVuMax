﻿
    export class rigStateItem {
        Number: number = 0;
        Name: string = "";
        Color: number = 0;
    }
