﻿
    export class AutoSlideSettings {

        FromDepth: number = 0;
        ToDepth: number = 0;
        MinTorque: number = 0;
        MaxTorque: number = 0;
        CalibrationRows: number = 0;
        MinTorqueDiff: number = 0;
        MinRPM: number = 0;
        MaxRPM: number = 0;
    }
