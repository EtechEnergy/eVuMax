﻿export class RoleWellPermission {
  RoleID: number = 0;
  PermissionOn: string = "";
  ObjectID: string = "";
}
