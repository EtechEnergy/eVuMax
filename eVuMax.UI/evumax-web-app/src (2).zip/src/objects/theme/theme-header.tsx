import ThemeProps from "./theme-props";

export default class ThemeHeader {

    Id : string  | number | string[] | undefined ="";
    Name : string  | number | string[] | undefined ="" //Common
    props: ThemeProps[] = [];

}


