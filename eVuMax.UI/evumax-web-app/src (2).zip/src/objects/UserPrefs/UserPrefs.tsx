export default class UserPrefs {

    UserId : string  | number | string[] | undefined ="";
    ThemeId: string  | number | string[] | undefined ="" //Common
   

}