﻿using eVuMax.DataBroker.Broker;
using eVuMax.DataBroker.GenericDrillingSummary;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eVuMax.DataBroker.Summary.DrlgStand
{
    public class DrlgStandPlotMgr : IBroker
    {
        const string generateDrlgStandPlot = "generateDrlgStandPlot";
        const string saveUserSettings = "SaveUserSettings";
        public BrokerResponse getData(BrokerRequest paramRequest)
        {
            try
            {

                Broker.BrokerResponse objResponse = paramRequest.createResponseObject();
                if (paramRequest.Function == generateDrlgStandPlot)
                {
               
                    DrlgStandUserSettings objeVuMaxSettings = new DrlgStandUserSettings();
                    string streVuMaxSettings = "";
                    streVuMaxSettings = paramRequest.Parameters.Where(x => x.ParamName.Contains("UserSettings")).FirstOrDefault().ParamValue.ToString();
                    bool loadDSfromDB = Convert.ToBoolean(paramRequest.Parameters.Where(x => x.ParamName.Contains("loadDSfromDB")).FirstOrDefault().ParamValue);


                    //????
                    
                    if (streVuMaxSettings != "")
                    {
                        objeVuMaxSettings = JsonConvert.DeserializeObject<DrlgStandUserSettings>(streVuMaxSettings);
                        if (objeVuMaxSettings.RealTime)
                        {
                            //objStandUserSettings.SelectionType = eNumSelectionType.ByHrs;
                            //objeVuMaxSettings.SelectionType = sPlotSelectionType.ByHours;
                            objeVuMaxSettings.SelectionType = eNumSelectionType.ByHrs;
                        }
                    }


                    DrlgStandPlot objDrlgStandPlot = new DrlgStandPlot();
                    paramRequest.objDataService.UserName = objeVuMaxSettings.UserID;
                    objDrlgStandPlot.objRequest = paramRequest;


                    UserSettings.UserSettingsMgr objSettingsMgr = new UserSettings.UserSettingsMgr(paramRequest.objDataService);

                    //DrlgStandUserSettings objNewVuMaxSettings.= new DrlgStandUserSettings();    //prath 14-Feb-2022

                    UserSettings.UserSettings objNewVuMaxSettings= new UserSettings.UserSettings();  //For save to EvuMax

                    if (loadDSfromDB) { //While load form 
                        objNewVuMaxSettings = objSettingsMgr.loadUserSettings(objeVuMaxSettings.UserID, "STANDREPORT", objeVuMaxSettings.WellID);


                        if (objNewVuMaxSettings == null)  //load setting from vumax
                        {
                            objDrlgStandPlot.objDataSelection.loadDataSelection("STANDREPORT");  //load from Vumax
                            objNewVuMaxSettings.settingData = "" //Pending
                        }
                    }
                    else
                    {
                        //Get seetings from GUI 
                        objNewVuMaxSettings.settingData = streVuMaxSettings;
                    }
                    


                    //WIP PRATH 14-FEB-2022
                    if (objNewVuMaxSettings!= null)
                    {
                        objeVuMaxSettings = new DrlgStandUserSettings();
                        //ReInitlize UserSettings from Database
                        objeVuMaxSettings = JsonConvert.DeserializeObject<DrlgStandUserSettings>(objNewVuMaxSettings.settingData); 
                        objDrlgStandPlot.objDataSelection.objRequest = paramRequest;
                        objDrlgStandPlot.objDataSelection.WellID = objeVuMaxSettings.WellID;
                        
                        if (objNewVuMaxSettings.settingData == "")
                        {
                            objDrlgStandPlot.objDataSelection.loadDataSelection("STANDREPORT");  //load from Vumax
                        }
                        else
                        {
                            //assign eVuMax User Settings to dataSelector of VuMax
                            objDrlgStandPlot.objDataSelection.selectionType = (DataSelection.sPlotSelectionType)objeVuMaxSettings.SelectionType;
                            objDrlgStandPlot.objDataSelection.LastHours = objeVuMaxSettings.LastHrs;
                            objDrlgStandPlot.objDataSelection.FromDate = objeVuMaxSettings.FromDate;
                            objDrlgStandPlot.objDataSelection.ToDate = objeVuMaxSettings.ToDate;
                            objDrlgStandPlot.objDataSelection.FromDepth = objeVuMaxSettings.FromDepth;
                            objDrlgStandPlot.objDataSelection.ToDepth = objeVuMaxSettings.ToDepth;
                        }





                        //if (objeVuMaxSettings.RealTime)
                        //{
                        //    objDrlgStandPlot.objDataSelection.selectionType = DataSelection.sPlotSelectionType.ByHours;
                        //    objDrlgStandPlot.objDataSelection.LastHours = objeVuMaxSettings.LastHrs;

                        //}


                        if (objDrlgStandPlot.objDataSelection.)
                        {
                            objDrlgStandPlot.objDataSelection.selectionType = DataSelection.sPlotSelectionType.ByHours;
                            objDrlgStandPlot.objDataSelection.LastHours = objeVuMaxSettings.LastHrs;

                        }


                    }
                    else //load VuMax DataSelector object as its not in eVuMax UserSetting table
                    {
                        objNewVuMaxSettings= new UserSettings.UserSettings();
                        objDrlgStandPlot.objDataSelection.objRequest = paramRequest;
                        objDrlgStandPlot.objDataSelection.objRequest.objDataService.UserName = objeVuMaxSettings.UserID;
                        objDrlgStandPlot.objDataSelection.WellID = objeVuMaxSettings.WellID;

                        objDrlgStandPlot.objDataSelection.loadDataSelection("STANDREPORT");

                        objeVuMaxSettings.FromDate = objDrlgStandPlot.objDataSelection.FromDate;
                        objeVuMaxSettings.ToDate = objDrlgStandPlot.objDataSelection.ToDate;
                        objeVuMaxSettings.FromDepth = objDrlgStandPlot.objDataSelection.FromDepth;
                        objeVuMaxSettings.ToDepth = objDrlgStandPlot.objDataSelection.ToDepth;

                        objeVuMaxSettings.LastHrs = objDrlgStandPlot.objDataSelection.LastHours;
                        objeVuMaxSettings.SelectionType = (sPlotSelectionType) objDrlgStandPlot.objDataSelection.selectionType;

                        //switch (objDrlgStandPlot.objDataSelection.selectionType)
                        //{
                        //    case DataSelection.sPlotSelectionType.ByHours:
                        //        //objeVuMaxSettings.SelectionType = eNumSelectionType.DefaultByHrs;
                        //        objeVuMaxSettings.SelectionType = sPlotSelectionType.ByHours;
                        //        break;

                        //    case DataSelection.sPlotSelectionType.DateRange:
                        //        objeVuMaxSettings.SelectionType = sPlotSelectionType.DateRange;
                        //        break;
                        //    case DataSelection.sPlotSelectionType.DepthRange: 
                        //        objeVuMaxSettings.SelectionType = sPlotSelectionType.DepthRange;
                        //        break;
                        //}
                        //Saving React side UserSetting to eVuMax into UserSetting table.
                        objNewVuMaxSettings.UserId = objeVuMaxSettings.UserID;
                        objNewVuMaxSettings.settingData = JsonConvert.SerializeObject(objeVuMaxSettings);
                        objNewVuMaxSettings.WellId = objeVuMaxSettings.WellID;
                        objNewVuMaxSettings.SettingsId = "STANDREPORT";

                        objSettingsMgr.saveUserSettings(objNewVuMaxSettings);
                    }


                 

                    objDrlgStandPlot.objUserSettings = objeVuMaxSettings;
                   // wellID = objStandUserSettings.WellID; //work around
                    
                  
                    
                    objResponse = objDrlgStandPlot.generateReportData(ref paramRequest, objeVuMaxSettings.WellID);
                    if(objResponse.RequestSuccessfull == false)
                    {
                        objResponse.Warnings = objResponse.Errors;
                    }
                    return objResponse;
                }

                objResponse = paramRequest.createResponseObject();
                objResponse.RequestSuccessfull = false;
                objResponse.Errors = "Invalid request Broker header. Please use proper header in the Broker request";
                return objResponse;
            }

            catch (Exception ex)
            {

                Broker.BrokerResponse objResponse = paramRequest.createResponseObject();
                objResponse.Response = ex.Message + ex.StackTrace;
                return objResponse;
            }
        }

        public BrokerResponse performTask(BrokerRequest paramRequest)
        {
            try
            {
                Broker.BrokerResponse objResponse = paramRequest.createResponseObject();

                if (paramRequest.Function == saveUserSettings)
                {

                    DrlgStandUserSettings objStandUserSettings = new DrlgStandUserSettings();
                    string strStandSettings = "";
                    strStandSettings = paramRequest.Parameters.Where(x => x.ParamName.Contains("UserSettings")).FirstOrDefault().ParamValue.ToString();

                    if (strStandSettings != "")
                    {
                        objStandUserSettings = JsonConvert.DeserializeObject<DrlgStandUserSettings>(strStandSettings);
                    }

                    UserSettings.UserSettingsMgr objSettingsMgr = new UserSettings.UserSettingsMgr(paramRequest.objDataService);
                    UserSettings.UserSettings objNewVuMaxSettings= new UserSettings.UserSettings();
                    objNewVuMaxSettings.UserId = objStandUserSettings.UserID;
                    objNewVuMaxSettings.WellId = objStandUserSettings.WellID;
                    objNewVuMaxSettings.SettingsId = "STANDREPORT";
                    objNewVuMaxSettings.settingData = JsonConvert.SerializeObject(objStandUserSettings);
                    objSettingsMgr.saveUserSettings(objNewVuMaxSettings);

                }


                objResponse.RequestSuccessfull = true;
                objResponse.Errors = "";
                return objResponse;
            }
            catch (Exception ex)
            {
                Broker.BrokerResponse objResponse = paramRequest.createResponseObject();
                objResponse.Response = ex.Message + ex.StackTrace;
                return objResponse;

            }
        }
    }//Class
}//NameSpace
