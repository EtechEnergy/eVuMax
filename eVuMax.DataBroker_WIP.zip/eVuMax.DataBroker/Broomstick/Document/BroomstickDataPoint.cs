﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eVuMax.DataBroker.Broomstick.Document
{
    public class BroomstickDataPoint
    {

        public double Depth { get; set; } = 0;
        public double Value { get; set; } = 0;

    }
}
